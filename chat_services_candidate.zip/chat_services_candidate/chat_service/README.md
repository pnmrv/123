to run this service, run the following main method on this class:

de.affinitas.chat.service.ChatService

ava -jar ChatService-1.0.jar de.affinitas.chat.service.ChatService
