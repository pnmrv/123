package de.affinitas.chat;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class ChatServiceTest {

    @Test
    public void can()
    {
        assertThat(true, is(true));
    }


}
