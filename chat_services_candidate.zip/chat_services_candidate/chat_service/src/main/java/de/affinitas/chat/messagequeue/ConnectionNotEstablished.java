package de.affinitas.chat.messagequeue;

public class ConnectionNotEstablished extends RuntimeException {
}
