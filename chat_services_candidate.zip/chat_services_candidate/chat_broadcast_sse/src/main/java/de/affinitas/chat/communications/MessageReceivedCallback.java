package de.affinitas.chat.communications;

public interface MessageReceivedCallback {
    void call(String message);
}
