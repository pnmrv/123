to run this service, run the following main method on this class:

de.affinitas.chat.service.ChatBroadcastSSEService