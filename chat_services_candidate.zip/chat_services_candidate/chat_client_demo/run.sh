#!/usr/bin/env bash

python -m SimpleHTTPServer 8000